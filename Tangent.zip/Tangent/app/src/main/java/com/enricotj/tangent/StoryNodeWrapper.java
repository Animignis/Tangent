package com.enricotj.tangent;

import java.util.Date;
import java.util.List;

/**
 * Created by enricotj on 1/13/2016.
 */
public class StoryNodeWrapper {
    private Story story;
    private StoryNodeWrapper parent;

    private int id;
    private String title;
    private String author;
    private String body;
    private Date timestamp;

    private List<StoryNodeWrapper> branches;

    public StoryNodeWrapper() {

    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getBody() {
        return body;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public StoryNodeWrapper getParent() {
        return parent;
    }

    public Story getStory() {
        return story;
    }

    public List<StoryNodeWrapper> getBranches() {
        return branches;
    }
}
