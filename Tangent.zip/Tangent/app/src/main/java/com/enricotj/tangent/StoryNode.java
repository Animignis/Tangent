package com.enricotj.tangent;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Created by enricotj on 1/24/2016.
 */
public class StoryNode {
    private String author;
    private String body;
    private String branches;
    private int parent;
    private String timestamp;
    private int views;

    @JsonIgnore
    private String key;
}
