package com.enricotj.tangent;

/**
 * Created by enricotj on 1/13/2016.
 */
public class User {
    private String username;

    public User() {

    }

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
